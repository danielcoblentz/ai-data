# import the necessary packages
from tensorflow.keras.layers import BatchNormalization
from tensorflow.keras.layers import Conv2D
from tensorflow.keras.layers import MaxPooling2D
from tensorflow.keras.layers import Activation
from tensorflow.keras.layers import Flatten
from tensorflow.keras.layers import Dropout
from tensorflow.keras.layers import Dense
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Add
from tensorflow.keras.layers import GlobalAveragePooling2D
from tensorflow.keras import backend as K

class ResGestureNet:
    @staticmethod
    def conv_block(X, filters):
        # Retrieve Filters
        F1, F2 = filters
        X_shortcut = X

        # First component of main path
        X = Conv2D(filters=F1, kernel_size=(3, 3), strides=(1, 1), padding='same')(X)
        X = BatchNormalization(axis=-1)(X)
        X = Activation('relu')(X)

        # Second component of main path
        X = Conv2D(filters=F2, kernel_size=(3, 3), strides=(1, 1), padding='same')(X)
        X = BatchNormalization(axis=-1)(X)

        # Shortcut path
        X_shortcut = Conv2D(filters=F2, kernel_size=(1, 1), strides=(1, 1), padding='valid')(X_shortcut)
        X_shortcut = BatchNormalization(axis=-1)(X_shortcut)

        # Add shortcut value to main path, and pass it through a RELU activation
        X = Add()([X, X_shortcut])
        X = Activation('relu')(X)
        
        return X

    @staticmethod
    def build(width, height, depth, classes):
        # Define the input shape
        inputShape = (height, width, depth)

        if K.image_data_format() == "channels_first":
            inputShape = (depth, height, width)

        # Define the input placeholder as a tensor with shape input_shape
        X_input = Input(inputShape)

        # Zero-Padding
        X = Conv2D(16, (7, 7), strides=(1, 1), padding='same')(X_input)
        X = BatchNormalization(axis=-1)(X)
        X = Activation('relu')(X)

        # Stage 1
        X = ResGestureNet.conv_block(X, filters=[32, 32])
        X = MaxPooling2D((2, 2))(X)

        # Stage 2
        X = ResGestureNet.conv_block(X, filters=[64, 64])
        X = MaxPooling2D((2, 2))(X)

        # Output layer
        X = GlobalAveragePooling2D()(X)
        X = Dropout(0.5)(X)
        X = Dense(classes, activation='softmax')(X)

        # Create model
        model = Model(inputs=X_input, outputs=X, name='ResGestureNet')

        return model
